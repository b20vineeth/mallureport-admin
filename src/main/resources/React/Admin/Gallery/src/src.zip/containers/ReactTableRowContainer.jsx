import { connect } from 'react-redux';
import ReactTableRow from '../components/ReactTableRow';
import React, { Component } from 'react' 

const mapStateToProps = (state) => {
  return {
    columnList: getColumnList(state),
    fieldData: getfieldData(state) 
  };
};

//const getData = state => state.dataListReducer.datasss;
const getColumnList = state => state.dataListReducer.columns;
const getfieldData = state => state.dataListReducer.fieldData;
const mapDispatchToProps = (dispatch) => {

  return {}
}
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(ReactTableRow); 