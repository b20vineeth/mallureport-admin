export const SET_FILTERTEXT = 'SET_FILTERTEXT';
export const CONTACTS = 'CONTACTS';
export const LIST_SUCCESS = 'LIST_SUCCESS';
export const DELETE_ROW = 'DELETE_ROW';
export const EDIT_ROW = 'EDIT_ROW';
export const ADD_ROW = 'ADD_ROW';

export const DATA_SAVE= 'DATA_SAVE';
export const GALLERY_SAVE= 'GALLERY_SAVE';
export const SAVE_FIELD_DATA= 'SAVE_FIELD_DATA';


