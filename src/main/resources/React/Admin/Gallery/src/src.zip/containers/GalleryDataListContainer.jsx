
import { connect } from 'react-redux';
import GalleryDataList from '../components/GalleryDataList'; 
import React, { Component } from 'react'
import { getContactsFn } from '../actions/actions'
import { LoadingHOC } from '../hoc/LoadingHOC'
 
const GalleryListWrapper = LoadingHOC('galleryList')(GalleryDataList)

class GalleryDataListContainer extends Component {

  state = {
    isLoading: true 
  }
    componentDidMount() {
        this.props.getGallery()
  }


    render() {
     
        return (<GalleryListWrapper galleryList={this.props.galleryList} />)
       
       
    }
}
const mapStateToProps = (state) => ({
  galleryList: getGallery(state)

})
const getGallery = state => state.galleryReducer.galleryData;
 
const mapDispatchToProps = (dispatch) => ({
  getGallery: () => dispatch(getContactsFn)
})
export default connect(mapStateToProps, mapDispatchToProps)(GalleryDataListContainer)