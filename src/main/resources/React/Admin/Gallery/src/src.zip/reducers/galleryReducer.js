import * as types from '../actions/action-types'

const INITIAL_STATE = {
  galleryData: [],
  isLoading:true, 
  datas:[],
  page:0,

}
 


export const galleryReducer = (state = INITIAL_STATE, action) => {
  
  switch (action.type) {

    case types.LIST_SUCCESS:
      return Object.assign({}, state, { galleryData: action.data,isLoading:false}) 
    
     
    default:
      return state
  }
}
