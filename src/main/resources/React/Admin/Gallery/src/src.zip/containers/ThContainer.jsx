import { connect } from 'react-redux';
import TableHead from '../components/TableHead'
import React, { Component } from 'react' 

const mapStateToProps = (state) => {
  return {
    
  };
};

 const mapDispatchToProps = (dispatch) => {

  return {}
}
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(TableHead); 