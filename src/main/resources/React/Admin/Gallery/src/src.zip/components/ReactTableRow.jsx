import React, { Component } from 'react'
import ThContainer from '../containers/ThContainer'
import TdContainer from '../containers/TdContainer'
export default class ReactTableRow extends Component {
  constructor(props) {
    super(props);


  }
  render() {
    var elementHead = [];
    var arr = Object.values(this.props.columnList);
    arr.forEach(element => {
      elementHead.push(<ThContainer  headerStyle={element.headerStyle} Header={element.Header} />)

    })
    var elementBody = [];
    var fieldData = Object.values(this.props.fieldData);
    fieldData.forEach(element => {

        elementBody.push(<TdContainer  content={element} />)

    })

    return (
      <React.Fragment>
        <thead>
          <tr>
            {
              elementHead
            }
          </tr>
        </thead>

    
       
        <tbody>
          
            {
              elementBody
            }
         
        </tbody>
      </React.Fragment>


        )
  }
}
