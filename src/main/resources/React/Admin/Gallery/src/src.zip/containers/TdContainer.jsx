import { connect } from 'react-redux';
import TableBody from '../components/TableBody'
import React, { Component } from 'react' 

const mapStateToProps = (state) => {
  return {
    
  };
};

 const mapDispatchToProps = (dispatch) => {

  return {}
}
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(TableBody); 