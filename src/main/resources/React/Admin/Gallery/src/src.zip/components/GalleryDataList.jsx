
import React, { Component } from 'react'
import ReactTableContainer from '../containers/ReactTableContainer'
const columns = [
    {
      Header: 'Title',
      accessor: 'name',
      headerStyle: 'col-xs-3',
      style: 'col-xs-3',
    },
    {
      Header: 'Short Desc',
      accessor: 'email',
      headerStyle: 'col-xs-3',
      style: 'col-xs-3',
    },
    {
        Header: 'Created By',
        accessor: 'thumbnail',
        headerStyle: 'col-xs-2',
        style: 'col-xs-2',
      },
      {
        Header: 'Tag',
        accessor: 'name',
        headerStyle: 'col-xs-3',
        style: 'col-xs-3',
      },
      {
        Header: 'Tag',
        accessor: 'name',
        headerStyle: 'col-xs-1',
        style: 'col-xs-1',
      },
    
  ];
export default class GalleryDataList extends Component {
     
    state = {
        isLoading: true ,
        galleryList:this.props.galleryList
      }
      
    render() { 
      
        return (
               <ReactTableContainer columns={columns}></ReactTableContainer>


        )
    }
}
