import { connect } from 'react-redux';
import ReactTable from '../components/ReactTable';
import React, { Component } from 'react'
import { getRenderTable } from '../actions/actions'

const mapStateToProps = (state) => {
  return {
    dataList: getDataList(state),
    datasss: getData(state),
    fieldData: getfieldData(state) 
  };
};

const getData = state => state.dataListReducer.datasss;
const getDataList = state => state.galleryReducer.galleryData;
const getfieldData = state => state.dataListReducer.fieldData;
const mapDispatchToProps = (dispatch) => {

  return {

    dataLoad: (data, columns) => {
      console.log(columns)
      dispatch({ type: 'DATA_SAVE', data: data, columns: columns });
      dispatch(getRenderTable);
    }
  }
}
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(ReactTable); 