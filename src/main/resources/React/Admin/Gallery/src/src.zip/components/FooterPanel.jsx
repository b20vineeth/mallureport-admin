import React, { Component } from 'react'   

export default class FooterPanel extends Component {
    constructor(props) {
        super(props);
        this.state = {}
    } 
   
    render() {
        return (
  
          
          
   <div className="footer">
    <strong>    copyRight @ Vineeth</strong>
        </div>
            )
      }
  }
  