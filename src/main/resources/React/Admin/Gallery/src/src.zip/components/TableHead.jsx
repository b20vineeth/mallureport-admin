import React, { Component } from 'react'
export default class TableHead extends Component {
    constructor(props) {
        super(props);


    }
    render() {

         let type=this.props.type;
        return (
             
                
                  <th className={this.props.headerStyle}>{this.props.Header}</th>
             
              
        )
    }
}
