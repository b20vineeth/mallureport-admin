import React, { Component } from 'react'
export default class TDPanel extends Component {
    constructor(props) {
        super(props);


    }
    render() {
 
        return (
             
                
                  <td className={this.props.style}>{this.props.accessor}</td>
             
              
        )
    }
}
