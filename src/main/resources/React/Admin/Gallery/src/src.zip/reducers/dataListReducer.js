import * as types from '../actions/action-types'

const INITIAL_STATE = {
    
  datasss:[],
  page:1,
  pageSize:25,
  columns:"",
  fieldData:[]

}
export const dataListReducer = (state = INITIAL_STATE, action) => {
   switch (action.type) {

   case types.DATA_SAVE:
        return {  ...state, datasss:action.data,columns:action.columns}
  case types.SAVE_FIELD_DATA:
     return {  ...state, fieldData:action.data}
    default:
      return state
  }
}
